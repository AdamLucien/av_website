window.NDATA = {
  lang: "cs",

  period: { start: "2024-09-01 00:00:00", end: "2025-09-13 23:59:59" },

  totals: {
    all_incl_media: 84541,
    no_media: 84541, // čistě textové interakce (viz export definice)
    days_active: 378
  },

  by_author: {
    you: 46281,
    her: 38260,
    share_you: 55.0,
    share_her: 45.0,
    avg_words_you: 11.7,
    avg_words_her: 6.8
  },

  media: {
    images: 3711,
    videos: 780,
    audios: 322,
    gifs: 585,
    stickers: 261,
    documents: 29
  },

  deleted: {
    total: 756,
    by_author: { you: null, her: null } // není přesně určeno v exportu → doplnitelné
  },

  replies: {
    median_sec_you: 20,
    median_sec_her: 28,
    openers_days: { you: 209, her: 159 }
  },

  activity: {
    top_hour_24h: 22,
    share_20_23_percent: 31.0,
    daily_avg_no_media: 230.0,
    daily_peak: { date: "2024-10-29", count: 669 }
  },

  gaps: [
    { from: "2024-12-06 00:00:00", to: "2024-12-12 03:00:00", hours: 147.0 },
    { from: "2025-02-15 00:00:00", to: "2025-02-20 05:00:00", hours: 118.0 },
    { from: "2025-06-02 00:00:00", to: "2025-06-03 09:00:00", hours: 33.0 },
    { from: "2025-08-11 00:00:00", to: "2025-08-12 04:00:00", hours: 28.0 }
  ],

  sentiment: {
    positive_rate_percent: 20.5,
    negative_rate_percent: 2.1,
    peaks: { positive: ["2024-09","2025-03"], negative: ["2025-01","2025-06"] }
  },

  calls: {
    // Přesná čísla hovorů v exportu nebyla spolehlivě doložená – držíme agregátový slot
    total: null,
    voice: { received: null, missed: null },
    video: { received: null, missed: null },
    by_author: { you: null, her: null }
  },

  milestones: [
    { date: "2024-09-03 16:06",  type: "love",    text_cs: "„Кохаю тебе безмежно 😘“ – první silné vyznání od ní.", text_ua: "«Кохаю тебе безмежно 😘» — перше сильне зізнання від неї." },
    { date: "2024-09-03 21:48",  type: "love",    text_cs: "„Má lásko 💗“ od ní.", text_ua: "«Моє кохання 💗» від неї." },
    { date: "2024-09-03 20:00",  type: "symbol",  text_cs: "Motiv „déšť nás spojil”.", text_ua: "Мотив «дощ нас поєднав»." },
    { date: "2024-12-06",        type: "gap",     text_cs: "Začátek nejdelšího ticha (~6 dní).", text_ua: "Початок найдовшої паузи (~6 днів)." },
    { date: "2025-02-15",        type: "gap",     text_cs: "Druhé delší ticho (~5 dní).", text_ua: "Друга довша пауза (~5 днів)." },
    { date: "2025-09-13 22:45",  type: "love",    text_cs: "13 měsíců – stále „spolu“.", text_ua: "13 місяців — все ще «разом»." }
  ],

  narrative_phases: [
    { range: ["2024-09-01","2024-09-15"],  title_cs: "Záblesk & přilnutí",         note_cs: "Rychlé prohloubení intimity, rituály (déšť), první tření.", title_ua: "Спалах і зближення", note_ua: "Швидке зближення, ритуали (дощ), перші тертя." },
    { range: ["2024-10-01","2024-12-31"], title_cs: "Konsolidace, vysoká kadence", note_cs: "Více plánování, občasné hádky, 6denní ticho v prosinci.", title_ua: "Консолідація",          note_ua: "Багато планів, іноді сварки, груднева пауза." },
    { range: ["2025-01-01","2025-02-28"], title_cs: "Vysoké emoce + únava",         note_cs: "Leden emotivní, únorový propad a 5denní výpadek.", title_ua: "Емоції + втома", note_ua: "Січень емоційний, у лютому — спад і пауза." },
    { range: ["2025-03-01","2025-03-31"], title_cs: "Rekalibrace & nejlepší nálada",note_cs: "Březen s nejvyšším pozitivním poměrem.", title_ua: "Рекалібрування", note_ua: "Березень — найвищий позитив." },
    { range: ["2025-04-01","2025-07-31"], title_cs: "Vlnění & testy",              note_cs: "Nahoru/dolů, méně pozitivních výrazů, únava okolí.", title_ua: "Хвилювання", note_ua: "Коливання, менше позитиву." },
    { range: ["2025-08-01","2025-09-13"], title_cs: "Mikroodstupy bez rozchodu",   note_cs: "Dvě ~28h pauzy, ale láskyplnost drží.", title_ua: "Мікропауза", note_ua: "Дві ~28 год паузи, близькість зберігається." }
  ],

  clusters: {
    intimacy_sex: 1085,
    kids_family_total: 1031,
    mother: 230,
    husband: 110,
    work_shifts_meetings: 913,
    phone_calling: 996,
    jealousy_lines: 93,
    emotional_load_total: 1112 // slova: strach/bolí/pláč apod. (součet kategorií)
  },

  copy: {
    cs: {
      landing_h1: "13 měsíců. Ne statistika. Náš příběh.",
      landing_p:  "Viko, tohle je pro tebe: náš déšť, naše ticha, naše SPOLU.",
      cta_start:  "Začít příběh",
      data_meaning: {
        msgs:  "Hodně? Ano. Ale tohle je náš jazyk blízkosti.",
        media: "Někdy místo slov stačí obraz.",
        calls: "Dovolat se znamená: „Potřebuji tě teď.“",
        gaps:  "Dvakrát jsme zmlkli. Dvakrát jsme se vrátili.",
        reply: "Reagujeme rychle. Srdce otevřené."
      }
    },
    ua: {
      landing_h1: "13 місяців. Не статистика. Наша історія.",
      landing_p:  "Віко, це для тебе: наш дощ, наші паузи, наше РАЗОМ.",
      cta_start:  "Почати історію",
      data_meaning: {
        msgs:  "Багато? Так. Але це — наша мова близькості.",
        media: "Іноді замість слів достатньо образу.",
        calls: "Дзвінок означає: «Потрібна/потрібен ти зараз».",
        gaps:  "Двічі ми мовчали. Двічі ми повернулися.",
        reply: "Реагуємо швидко. Серце відкрите."
      }
    }
  },

  // Rozšířený měsíční rozbor (kostra). Doplň přesná čísla po měsících 09/2024–09/2025.
  monthly: [
    // Příklad položky; duplikuj pro každý měsíc:
    {
      month: "2024-09",
      overall:  { total: null, no_media: null, text: null, deleted: null,
                  media: { images: null, videos: null, audios: null, gifs: null, stickers: null, documents: null } },
      adam:     { total: null, no_media: null, text: null, deleted: null },
      vika:     { total: null, no_media: null, text: null, deleted: null },
      calls:    { total: null, voice: { received: null, missed: null }, video: { received: null, missed: null } },
      mood:     { positive_pct: null, negative_pct: null },
      notes:    { cs: "Rychlé přilnutí, první vyznání, motiv deště.", ua: "Швидке зближення, перші зізнання, мотив дощу." }
    }
  ],

  // Denní/časová granularita – volitelné sloty pro heatmapy; vyplň, pokud chceš grafy na /stats
  timeseries: {
    by_day_no_media: [],   // [{date:"2024-09-01", count:123}, ...]
    by_hour_avg:    [],    // [{hour:0,count:..}, ...]
    by_week:        []     // [{week:"2024-W36", count:...}, ...]
  }
};